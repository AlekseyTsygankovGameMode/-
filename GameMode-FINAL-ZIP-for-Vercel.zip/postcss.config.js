// postcss.config.js
export default {
  plugins: {
    // TailwindCSS utilities & layers
    tailwindcss: {},
    // Automatically add vendor prefixes for compatibility
    autoprefixer: {},
  },
};